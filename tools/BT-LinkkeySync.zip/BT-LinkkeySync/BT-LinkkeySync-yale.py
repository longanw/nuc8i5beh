#!/usr/bin/env python
#-*- coding: utf-8 -*-

from plistlib import *
import os
from pprint import *
import subprocess

print("---------------------------------")
print("  BT-Linkkeysync by DigitalBird")
print("  https://github.com/digitalbirdo/BT-LinkkeySync")
print("  Modified by Yale Wei")
print("---------------------------------")

# 设置保存的注册表文件，之后需将键鼠无关的行删除
filename = 'btkeys.reg'

print("> 从blued.plist读取蓝牙信息")
output = subprocess.check_output("sudo defaults export /private/var/root/Library/Preferences/com.apple.bluetoothd.plist ./blued.plist", shell=True)

print("> 转换二进制为xml格式")
output = subprocess.check_output("sudo plutil -convert xml1 ./blued.plist", shell=True)

print("> 解析转换的plist文件")
pl = readPlist("./blued.plist")

# 打开注册表文件以便写入键值
f = open(filename, 'w')

# 转换函数定义，插入“,"或者调换顺序
# 参数s为读入的字符串，splitChar为插入的符号，flag为顺序标识，负数表示反序
def convertToWinRep(s,splitChar,flag):
        if  flag < 0:
	        return splitChar.join(map(str.__add__, s[-2::-2] ,s[-1::-2]))
        else:
                return splitChar.join(map(str.__add__, s[::2] ,s[1::2]))

print("> 转换键值并存入btkeys.reg文件")

# 注册表标识行
f.write("Windows Registry Editor Version 5.00")

# 蓝牙2.0设备查找循环
if "LinkKeys" in pl:
	print("  找到蓝牙2.0设备信息: "+str(len(pl["LinkKeys"].keys()))+ " 条连接键")
	for adapter in pl["LinkKeys"].keys():
		f.write('\r\n\r\n[HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\BTHPORT\\Parameters\\Keys\\'+adapter.replace("-","")+"]")

		# 查找所有蓝牙2.0设备
		for device in pl["LinkKeys"][adapter].keys():
			f.write('\r\n"'+device.replace("-","")+'"=hex:'+ convertToWinRep(pl["LinkKeys"][adapter][device].data.encode("hex"),",",1))
else:
	print("无任何蓝牙2.0设备信息")

# 蓝牙4.0设备查找循环
if "SMPDistributionKeys" in pl:
	print("  找到蓝牙4.0设备信息: "+str(len(pl["SMPDistributionKeys"].keys()))+ " 条")
	for adapter in pl["SMPDistributionKeys"].keys():

		# 查找所有蓝牙4.0设备
		for device in pl["SMPDistributionKeys"][adapter].keys():
			dev = '\r\n\r\n[HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\BTHPORT\\Parameters\\Keys\\'+adapter.replace("-","")+'\\'+device.replace("-","") +"]"
			
			# Lonk-Term Key (LTK) 顺序相同，插入分号复制
			# 128-bit key used to generate the session key for an encrypted connection.
                        dev += '\r\n"LTK"=hex:'+ convertToWinRep(pl["SMPDistributionKeys"][adapter][device]["LTK"].data.encode("hex"),",",1)
                                
			dev += '\r\n"KeyLength"=dword:'+ pl["SMPDistributionKeys"][adapter][device]["LTKLength"].data.encode("hex").rjust(8,'0')

			# Random Number (RAND), 顺序相同，插入分号复制
			# 64-bit stored value used to identify the LTK. A new RAND is generated each time a unique LTK is distributed.
			dev += '\r\n"ERand"=hex(b):'+ convertToWinRep(pl["SMPDistributionKeys"][adapter][device]["RAND"].data.encode("hex"),",",1)

			# Encrypted Diversifier (EDIV), 顺序相反，只调换顺序
			# 16-bit stored value used to identify the LTK. A new EDIV is generated each time a new LTK is distributed.
			dev += '\r\n"EDIV"=dword:'+ convertToWinRep(pl["SMPDistributionKeys"][adapter][device]["EDIV"].data.encode("hex"),"",-1).rjust(8,'0')

			# Identity Resolving Key (IRK), 顺序相反，插入分号
			# 128-bit key used to generate and resolve random address.
			dev += '\r\n"IRK"=hex:'+ convertToWinRep(pl["SMPDistributionKeys"][adapter][device]["IRK"].data.encode("hex"),",",-1)

			# Device Address, 顺序相反
			# 48-bit Address of the connected device
			dev += '\r\n"Address"=hex(b):'+ convertToWinRep(pl["SMPDistributionKeys"][adapter][device]["Address"].data.encode("hex").rjust(16,'0'),",",-1)

			# 以下三列照搬windows导出的信息
			dev += '\r\n"AddressType"=dword:00000001'
			dev += '\r\n"MasterIRKStatus"=dword:00000001'
			dev += '\r\n"AuthReq"=dword:0000002d'

			f.write(dev)
else:
	print("无任何蓝牙2.0设备信息")

f.close()
print("> 注册表文件已写好，请将键鼠无关的条目删除后即可在Windows下导入")
